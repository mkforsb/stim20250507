<?php
namespace Mikael\Task1;

interface PayoutReportParser {
    public function tryParse(mixed $report): PayoutReport;
}
